from project.reptile import Reptile


class Lizard(Reptile):
    pass
